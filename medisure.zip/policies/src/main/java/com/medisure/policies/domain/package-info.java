/**
 * Domain objects.
 */
package com.medisure.policies.domain;
