/**
 * Application configuration.
 */
package com.medisure.policies.config;
