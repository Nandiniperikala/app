/**
 * Data transfer objects for rest mapping.
 */
package com.medisure.policies.service.dto;
