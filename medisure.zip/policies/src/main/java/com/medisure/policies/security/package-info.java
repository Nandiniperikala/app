/**
 * Application security utilities.
 */
package com.medisure.policies.security;
