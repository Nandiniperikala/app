/**
 * Rest layer error handling.
 */
package com.medisure.policies.web.rest.errors;
