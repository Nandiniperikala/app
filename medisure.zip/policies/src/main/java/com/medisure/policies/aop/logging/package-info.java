/**
 * Logging aspect.
 */
package com.medisure.policies.aop.logging;
