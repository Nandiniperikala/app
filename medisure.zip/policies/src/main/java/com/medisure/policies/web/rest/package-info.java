/**
 * Rest layer.
 */
package com.medisure.policies.web.rest;
