/**
 * Rest layer error handling.
 */
package com.medisure.app.web.rest.errors;
