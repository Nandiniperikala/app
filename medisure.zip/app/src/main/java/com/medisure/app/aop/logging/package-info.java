/**
 * Logging aspect.
 */
package com.medisure.app.aop.logging;
