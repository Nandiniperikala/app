package com.medisure.app.config;

/**
 * Application constants.
 */
public final class Constants {

    public static final String DEFAULT_LANGUAGE = "en";

    private Constants() {}
}
