/**
 * Rest layer.
 */
package com.medisure.app.web.rest;
