/**
 * Rest layer visual models.
 */
package com.medisure.app.web.rest.vm;
