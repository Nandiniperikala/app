/**
 * Application configuration.
 */
package com.medisure.app.config;
