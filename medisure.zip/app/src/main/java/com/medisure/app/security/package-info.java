/**
 * Application security utilities.
 */
package com.medisure.app.security;
